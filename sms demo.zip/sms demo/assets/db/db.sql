 create database demosms2;

create table sms_category(
	ca_id  int auto_increment primary key,
	ca_name varchar(100),
	ca_time timestamp
);

create table sms_group(
	gr_id int auto_increment primary key,
	gr_name varchar(100),
	gr_time timestamp
);

create table person_contact(
	per_id int auto_increment primary key,
	per_name varchar(100),
	per_mobile bigint,
	per_grid varchar(100),	
	per_time timestamp
);

create table sms_message(
	sms_id int auto_increment primary key,
	sms_msg varchar(100),
	sms_caid int,
	sms_time timestamp	
);
CREATE TABLE sms_login (
  log_id int(11) ,
  log_name varchar(100) ,
  log_email varchar(100),
  log_mobile varchar(10),
  log_pass varchar(100) ,
  log_cpass varchar(100)
  -- `user_otp` int(11) NOT NULL
) ;

--
-- Dumping data for table `sms_login`
--

-- INSERT INTO `sms_login` (`user_id`, `user_name`, `user_email`, `user_mobile`, `user_password`, `user_otp`) VALUES
-- (1, 'Tapas', 'tapas@gmail.com', '8108715095', '7278934df282ee1027073d9eedbfee4735c627a5', 0),
-- (2, 'Aniket', 'aniket@gmail.com', '9658432104', '70c881d4a26984ddce795f6f71817c9cf4480e79', 0);
